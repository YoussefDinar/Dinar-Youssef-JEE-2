package com.example.customerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;


@SpringBootApplication
public class CustomerServiceApplication {

	public static void main(String[] args) {

		SpringApplication.run(CustomerServiceApplication.class, args);
	}
	/*@Bean
	CommandLineRunner start(CustomerRepository customerRepository){
		return args -> {
			customerRepository.saveAll(List.of(
					Customer.builder().name("Youssef").email("Youssef@gmail.com").build(),
					Customer.builder().name("test").email("test@gmail.com").build(),
					Customer.builder().name("tst").email("tst@gmail.com").build()
			));
			customerRepository.findAll().forEach(System.out::println);
		};
	}*/

}